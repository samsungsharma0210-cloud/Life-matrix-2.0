LIFE MATRIX Android project
===========================

Personalized for Pradeep. Includes the offline numerology app and an optional GitHub Actions cloud build workflow.

FEATURES
- Lo Shu grid and line interpretations
- Life Path calculator
- Pythagorean name numerology
- Daily numerology reflection
- Animated dark neon interface
- Profile storage on the device

BUILD USING A TABLET (CLOUD BUILD)
This project includes .github/workflows/build-apk.yml to build an APK in GitHub Actions, so you do not need Android Studio installed on your tablet.

High-level steps:
1. In your tablet browser, sign in to GitHub and create a new repository.
2. Upload the contents of this project ZIP into the repository, preserving the .github/workflows/build-apk.yml path. If your browser hides dot-folders, use GitHub's web editor to create that workflow file.
3. Commit the files to the main branch.
4. Open the repository's Actions tab and select "Build LIFE MATRIX APK".
5. Choose "Run workflow" if needed and wait for the workflow to finish successfully.
6. Open the completed workflow run, find Artifacts, and download "LIFE-MATRIX-debug-APK".
7. Extract the downloaded artifact ZIP to get app-debug.apk, then install it on your Android tablet. Android may ask you to allow installs from your browser or file manager.

If GitHub Actions is unavailable on your account, you may need to use a computer or another Android build service.

NOTES
- This ZIP is source code, not a precompiled APK.
- The cloud workflow creates a debug APK, not a Play Store release.
- Profile storage uses Android WebView local storage.
- The app works offline and does not request internet permissions.
- Numerology readings are for reflection, not scientifically validated predictions.
