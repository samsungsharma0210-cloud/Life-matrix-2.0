package com.lifematrix.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Window;
import android.view.View;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,11,22));
        getWindow().setNavigationBarColor(Color.rgb(8,11,22));
        getWindow().getDecorView().setSystemUiVisibility(0);
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,11,22));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        if (savedInstanceState == null) web.loadUrl("file:///android_asset/index.html");
        else web.restoreState(savedInstanceState);
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        View v = getWindow().getDecorView().findViewById(android.R.id.content);
        if (v instanceof WebView) ((WebView)v).saveState(outState);
    }
    @Override public void onBackPressed() {
        View v = getWindow().getDecorView().findViewById(android.R.id.content);
        if (v instanceof WebView && ((WebView)v).canGoBack()) ((WebView)v).goBack();
        else super.onBackPressed();
    }
}